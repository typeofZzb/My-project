<template>
    <div class="wrap">
        <div class="header">宝宝听</div>
        <div class="nav">
            <router-link v-for="(item,index) in navList" 
                :key="index"
                :to="item.link"
                tag="div"
            >{{item.title}}</router-link>
        </div>
        <div class="main">
            <router-view></router-view>
        </div>
        <My-foot/>
    </div>
</template>
<script>
import api from "../../api/index"
export default {
    props:{

    },
    components:{

    },
    data(){
        return {
            navList:[
                {
                    title:"儿歌",
                    link:"songs"
                },
                {
                    title:"故事",
                    link:"storys"
                },
            ]
        }   
    },
    computed:{

    },
    methods:{

    },
    created(){
        api.getlistenData("getlist",30,5).then(res=>{
            console.log(res,'--res')
        })
    },
    mounted(){

    }
}
</script>
<style lang="">

</style>